class Task:
    def __init__(self, name, due_date, url,  cid, task_type):
        self.name = name
        self.cid = cid
        self.due_date = due_date
        self.url = url
        self.type = task_type



